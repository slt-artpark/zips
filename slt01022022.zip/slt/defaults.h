#ifndef STL_DEFAULTS_H
#define STL_DEFAULTS_H

const float DEFAULT_VCC = 5.0;
const float DEFAULT_R_DIV = 10000.0;
const float DEFAULT_FLAT_RESISTANCE = 482812.5;
const float DEFAULT_BEND_RESISTANCE = 2507500.0;

/* right hand */

const float R_R_DIV_0 = 8730;
const float R_R_DIV_1 = 8570;
const float R_R_DIV_2 = 11850;
const float R_R_DIV_3 = 8100;
const float R_R_DIV_4 = 8890;

const float R_FLAT_RESISTANCE_0 = 8730;
const float R_FLAT_RESISTANCE_1 = 8570;
const float R_FLAT_RESISTANCE_2 = 11850;
const float R_FLAT_RESISTANCE_3 = 8100;
const float R_FLAT_RESISTANCE_4 = 8890;

const float R_BEND_RESISTANCE_0 = 12650;
const float R_BEND_RESISTANCE_1 = 11500;
const float R_BEND_RESISTANCE_2 = 18400;
const float R_BEND_RESISTANCE_3 = 11400;
const float R_BEND_RESISTANCE_4 = 12800;

/* left hand */

const float L_R_DIV_0 = 10200;
const float L_R_DIV_1 = 12720;
const float L_R_DIV_2 = 9400;
const float L_R_DIV_3 = 7750;
const float L_R_DIV_4 = 8400;

const float L_FLAT_RESISTANCE_0 = 10200;
const float L_FLAT_RESISTANCE_1 = 12720;
const float L_FLAT_RESISTANCE_2 = 9400;
const float L_FLAT_RESISTANCE_3 = 7750;
const float L_FLAT_RESISTANCE_4 = 8400;

const float L_BEND_RESISTANCE_0 = 14800;
const float L_BEND_RESISTANCE_1 = 22500;
const float L_BEND_RESISTANCE_2 = 16400;
const float L_BEND_RESISTANCE_3 = 11200;
const float L_BEND_RESISTANCE_4 = 13100;

#endif
